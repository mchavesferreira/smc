//------------------------------------------------------------------------------------- //
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.								//	
//------------------------------------------------------------------------------------- //
//=====================================================================================	//
//		ACIONANDO UM DISPLAY DE CRISTAL LIQUIDO DE 16x2									//
//																						//
//				Interface de dados de 4 bits											//
//=====================================================================================	//

#include "def_principais.h"			//inclus�o do arquivo com as principais defini��es 
#include "LCD.h"


/* LTC1298 Modo de operacao do conversor AD------------------- */
#define CH0 0xC /* Ler Chanel 0 */
#define CH1 0xE /* Ler Chanel 1 */
#define DF0 0x8 /* Ler (Chanel 0 - Chanel 1) */ 
#define DF1 0xA /* Ler (Chanel 1 - Chanel 0) */ 
#define LSB 0 /* Setar ordem LSB primeiro */
#define MSB 1 /* SSetar ordem MSB primeiro */
/* Definicao dos pinos SPI - pinos da placa Arduino ------------------- */
#define DD_SS (1<<DDB2) //pin 10: SS 
#define DD_MOSI (1<<DDB3) //pin 11: MOSI 
#define DD_MISO (1<<DDB4) //pin 12: MISO 
#define DD_SCK (1<<DDB5) //pin 13: SCK
#define habilita_SS() clr_bit(PORTB,PB2) // SS habilita em zero 
#define desabilita__SS() set_bit(PORTB,PB2)
#define BOTAO PD2 
#define CAL PD3
#define amostras 10 // define numero de amostras para media da leitura
void inic_SPI(); // funcao de inicializacao da comunicacao SPI
unsigned char SPI(unsigned char dado); // funcao de leitura e escrita de dado via SPI
int cont = 0; float flag = 0;
float flag1 = 0; float peso = 0;
float var0 = 1014; float var800 = 1060;
float var0_1 = 1011; float var800_1 = 1058;
unsigned int peso1 = 0; unsigned char digitos[4];
void spi();
void com_usart(); void escreve();
unsigned char tempH,tempL; // variaveis de 8 bits
unsigned int valor16bits; // variavel de 16 bits
unsigned char TEMP[tam_vetor]; // vetor para separacao de caracteres int tempo = 0;
int temp = 0;
int cali = 0;


//defini�ao para acessar a mem�ria flash 
PROGMEM const char mensagem[] = " DADOS DE 4BITS!\0"; //mensagem armazenada na mem�ria flash

//--------------------------------------------------------------------------------------
int main()
{	
    DDRD = 0xFF;					//PORTD como sa�da
	DDRB = 0xFF;

 inic_SPI();
 
	inic_LCD_4bits();				//inicializa o LCD
	escreve_LCD("  AD ");	//string armazenada na RAM
//	cmd_LCD(0xC0,0); 				//desloca cursor para a segunda linha
//	escreve_LCD_Flash(mensagem);	//string armazenada na flash

	while(1)
	{      spi();
         cmd_LCD(0xC0,0); 
				 peso1 = peso; 
						 ident_num(peso1,digitos);
						 cmd_LCD(digitos[3],1);
                        cmd_LCD(digitos[2],1);
						 cmd_LCD(digitos[1],1); 
						 cmd_LCD(digitos[0],1); 

   }						//la�o infinito
}
//======================================================================================	

 void inic_SPI() {
        DDRB = DD_MOSI | DD_SCK | DD_SS; //configurac?a?o dos pinos de entrada e sai?da da SPI
        PORTB |= ((1<<DD_SS)|(1<<DD_MOSI) | (1<<DD_SCK)); // estado inicial dos pinos
        SPSR &= ~(1<<SPI2X); // status do registrador duplex em zero
        SPCR &= ~((1<<SPIE) | (1<<CPHA) | (1<<DORD)| (1<<CPOL)) ; // bits com zero
        SPCR |= (1<<SPE) | (1<<MSTR) | (1<<SPR1) | (1<<SPR0); // bits com 1: habilita interrupcao dado ajustado na subida e amostragem na descida do sinal de clock
    } //----------------------------------------------------------------------------------------- //Envia e recebe um byte pela SPI //----------------------------------------------------------------------------------------- 
	
unsigned char SPI(unsigned char dado)
    {
        SPDR = dado;
        while(!(SPSR & (1<<SPIF))); 
		return SPDR;
        //envia um byte
        //espera envio
        //retorna o byte recebido
    }
	
void spi() {
    _delay_ms(500); // intervalo valor16bits=0; // inicia variavel em zero 0XXXXXXX XXXXX000
    habilita_SS(); 
	SPI(CH0 | MSB);
    tempH=SPI(0x00); 
	tempL=SPI(0x00);
    desabilita__SS();
//    for (int i=0; i<amostras; i++) 
	//{
        // inicio de loop de amostras
        // define canal de leitura AD e sequencia dos bits //envia vazio recebe MSB sequencia: 7 bits //envia vazio recebe LSB sequencia: 5 bits
        valor16bits = (tempH<<5) | ( tempL >>3); // Aglutina MSB+LSB descartando os zeros recebidos e soma-se
        _delay_ms(1); // intervalo entre as amostras }
        peso = valor16bits; // media das amostras
      //  flag = (-800*(var0-valor16bits)); 
	//	flag1 = (var0 - var800);
     //   peso = (flag/flag1);
     //   peso = (peso *(-1));
       // float flag = (17.58241758*valor16bits);
   // }
 }	
	
	

	
	