/// PROGRAMA PRECISA DE AJUSTES
//--------------------------------------------------------------------------------------------- //
// Instituto Federal de Sao Paulo - Campus Catanduva //
//--------------------------------------------------------------------------------------------- // /======================================================== //
// //
//Leitura do Conversor AD Ltc1298 com interface SPI
/* Referencias: AVR e Arduino: Te?cnicas de Projeto, 2a ed. - 2012. //
// //======================================================= //
Adaptacao: Prof. Marcos Chaves - Revisao: 26/5/16 //
*/
#include "def_principais.h" 
#include "USART.h" 
#include "LCD.h" 
#include <avr/interrupt.h>
/* LTC1298 Modo de operacao do conversor AD
 ------------------- */
#define CH0 0xC /* Ler Chanel 0 */
#define CH1 0xE /* Ler Chanel 1 */
#define DF0 0x8 /* Ler (Chanel 0 - Chanel 1) */
 #define DF1 0xA /* Ler (Chanel 1 - Chanel 0) */
  #define LSB 0 /* Setar ordem LSB primeiro */
#define MSB 1 /* SSetar ordem MSB primeiro */
/* Definicao dos pinos SPI - pinos da placa Arduino ------------------- */
#define DD_SS (1<<DDB2) //pin 10: SS
#define DD_MOSI (1<<DDB3) //pin 11: MOSI
#define DD_MISO (1<<DDB4) //pin 12: MISO 
#define DD_SCK (1<<DDB5) //pin 13: SCK
#define habilita_SS() clr_bit(PORTB,PB2) // SS habilita em zero 
#define desabilita__SS() set_bit(PORTB,PB2)
#define BOTAO PD2
#define CAL PD3
#define amostras 10 // define numero de amostras para media da leitura
void inic_SPI(); // funcao de inicializacao da comunicacao SPI
unsigned char SPI(unsigned char dado); // funcao de leitura e escrita de dado via SPI
PROGMEM const char mensagem[] = " DADOS DE 4BITS!\0"; //mensagem armazenada na memo?ria flash
int cont = 0; float flag = 0;
float flag1 = 0; float peso = 0;
float var0 = 1014; float var800 = 1060;
float var0_1 = 1011; float var800_1 = 1058;
unsigned int peso1 = 0; unsigned char digitos[4];
void spi();
void com_usart(); void escreve();
unsigned char tempH,tempL; // variaveis de 8 bits
unsigned int valor16bits; // variavel de 16 bits
unsigned char TEMP[tam_vetor]; // vetor para separacao de caracteres int tempo = 0;
int temp = 0;
int cali = 0;
//----------------------------------------------------------------------------------------- int main()
{
    inic_SPI();
    DDRD = 0B11110011; 
	PORTD = 0B00000000;
	 DDRB = 0XFF;
    while (1) {
        switch(temp) {
                //PORTD como sai?da
                //inicializa o LCD display
                cali = 1; 
				inic_LCD_4bits();
                cmd_LCD(0x01,0);
                //limpa todo o que os 3 digitos fiquem a direita do LCD
                cmd_LCD(0x80,0);
                //desloca o cursor para
            case 0 :   while((tst_bit(PIND,CAL)) && (temp == 0)) {
                             cmd_LCD(0x80,0); //desloca o cursor para que os 3 digitos fiquem a direita do LCD
                                 temp = 1; }   break; 
			case 1:  while(temp == 1)
                    escreve_LCD("CALIBRACAO"); if(tst_bit(PIND,BOTAO))
                    {
                        escreve_LCD("SEM PESO"); 
						spi();
                        cmd_LCD(0xC0,0); escreve_LCD(" PESO = ");
						 peso1 = peso;
						  ident_num(peso1,digitos);
                     //   cursor para que os 3 digitos fiquem a direita do LCD cmd_LCD(digitos[3],1);
                        cmd_LCD(digitos[2],1); 
						cmd_LCD(digitos[1],1); 
						cmd_LCD(digitos[0],1); 
						escreve_LCD("g");
                        if(tst_bit(PIND,BOTAO)) {
                            var0_1 = valor16bits;
                            //desloca o
                            {// que os 3 digitos fiquem a direita do LCD
                                cmd_LCD(0x80,0);
                                //desloca o cursor para
                                temp = 2; }
                        }
                        break; 
		case 2  :while(temp == 2)
                            ident_num(peso1,digitos); 
							cmd_LCD(digitos[3],1);
                            cmd_LCD(digitos[2],1);
                             escreve_LCD("COM PESO - 800g");
						     spi();
                             cmd_LCD(0xC0,0);
                             escreve_LCD(" PESO = ");
                            peso1 = peso;
                        { //que os 3 digitos fiquem a direita do LCD
                            cmd_LCD(0x80,0);
                            //desloca o cursor para
                            cmd_LCD(digitos[1],1); 
							cmd_LCD(digitos[0],1); 
							escreve_LCD("g");
                            if(tst_bit(PIND,BOTAO)) {
                                var800_1 = valor16bits;
                                temp = 3; }
                                    }
                        break;
						 case 3: while(temp == 3)
                            cmd_LCD(0xC0,0); //desloca o cursor para que os 3 digitos fiquem a direita do LCD
                                    }
                                    escreve_LCD("CALIBRACAO");
                                    escreve_LCD(" FINALIZADA"); _delay_ms(1500);
									     if(!tst_bit(PIND,CAL))
                                           {
                                            var0 = var0_1; var800 = var800_1;
                                         temp = 0; }
                                   } break;
                             spi(); _delay_ms(50); escreve(); _delay_ms(50); com_usart(); _delay_ms(50);
    }
} //----------------------------------------------------------------------------------------- //Inicializac?a?o da SPI //----------------------------------------------------------------------------------------- void escreve()
{
    inic_LCD_4bits(); cmd_LCD(0xC0,0); escreve_LCD(" PESO = "); peso1 = peso; ident_num(peso1,digitos);
    cmd_LCD(digitos[3],1); 
	cmd_LCD(digitos[2],1);
	 cmd_LCD(digitos[1],1); 
	 cmd_LCD(digitos[0],1); 
	 escreve_LCD("g");
    _delay_ms(200);
    //inicializa o LCD
}
void spi() {
    _delay_ms(500); // intervalo 
	valor16bits=0; // inicia variavel em zero
 //   0XXXXXXX XXXXX000
    habilita_SS(); 
	 m  SPI(CH0 | MSB);
    tempH=SPI(0x00);
	 tempL=SPI(0x00);
    desabilita__SS();
    for (int i=0; i<amostras; i++) {
        // inicio de loop de amostras
        // define canal de leitura AD e sequencia dos bits //envia vazio recebe MSB sequencia: 7 bits //envia vazio recebe LSB sequencia: 5 bits
        valor16bits += (tempH<<5) | ( tempL >>3); // Aglutina MSB+LSB descartando os zeros recebidos e soma-se
        _delay_ms(1); // intervalo entre as amostras 
		}
        valor16bits = valor16bits/amostras; // media das amostras
        flag = (-800*(var0-valor16bits)); flag1 = (var0 - var800);
        peso = (flag/flag1);
        peso = (peso *(-1));
        float flag = (17.58241758*valor16bits);
    }
    void com_usart() {
        //binario
        USART_Inic(MYUBRR); //inicializa comunicacao usart 
		escreve_USART("PESO = " ); 
		// envia porta serial a media do valor
        ident_num_usart(peso, TEMP); // rotina separa caracteres 
		USART_Transmite(TEMP[3]); USART_Transmite(TEMP[2]);
		 USART_Transmite(TEMP[1]); USART_Transmite(TEMP[0]);
    }
    //float 
	peso1 = (17800 - flag); 
	peso = (peso1 - 0);
    if(peso <= 0) {
        peso = (peso *(-1)); }
  //  escreve_USART('g'); 
//	escreve_USART('n');
	 // pula linha
    ident_num_usart(valor16bits, TEMP); // rotina separa caracteres 
	USART_Transmite(TEMP[3]);
    USART_Transmite(TEMP[2]);
    USART_Transmite(TEMP[1]);
    USART_Transmite(TEMP[0]); 
	//escreve_USART("\n " );
    void inic_SPI() {
        DDRB = DD_MOSI | DD_SCK | DD_SS; //configurac?a?o dos pinos de entrada e sai?da da SPI
        PORTB |= ((1<<DD_SS)|(1<<DD_MOSI) | (1<<DD_SCK)); // estado inicial dos pinos
        SPSR &= ~(1<<SPI2X); // status do registrador duplex em zero
        SPCR &= ~((1<<SPIE) | (1<<CPHA) | (1<<DORD)| (1<<CPOL)) ; // bits com zero
        SPCR |= (1<<SPE) | (1<<MSTR) | (1<<SPR1) | (1<<SPR0); // bits com 1: habilita interrupcao dado ajustado na subida e amostragem na descida do sinal de clock
    } //-----------------------------------------------------------------------------------------
	 //Envia e recebe um byte pela SPI 
	 //----------------------------------------------------------------------------------------- 
	 unsigned char SPI(unsigned char dado)
    {
        SPDR = dado;
        while(!(SPSR & (1<<SPIF))); 
		return SPDR;
        //envia um byte
        //espera envio
        //retorna o byte recebido
    }