
//--------------------------------------------------------------------------------------------- //
// Instituto Federal de Sao Paulo - Campus Catanduva //
//--------------------------------------------------------------------------------------------- // /======================================================== //
// //
//Leitura do Conversor AD Ltc1298 com interface SPI
//Referencias: AVR e Arduino: Te?cnicas de Projeto, 2a ed. - 2012. //
// //======================================================= //
//Adaptacao: Prof. Marcos Chaves - Revisao: 26/5/16 //
#include "def_principais.h"
#include "USART.h" 
#include "LCD.h"
 #include <avr/interrupt.h>
/* LTC1298 Modo de operacao do conversor AD
 ------------------- */
#define CH0 0xC /* Ler Chanel 0 */
#define CH1 0xE /* Ler Chanel 1 */
#define DF0 0x8 /* Ler (Chanel 0 - Chanel 1) */
#define DF1 0xA /* Ler (Chanel 1 - Chanel 0) */ 
#define LSB 0 /* Setar ordem LSB primeiro */
#define MSB 1 /* SSetar ordem MSB primeiro */
/* Definicao dos pinos SPI - pinos da placa Arduino ------------------- */
#define DD_SS (1<<DDB2) //pin 10: SS 
#define DD_MOSI (1<<DDB3) //pin 11: MOSI
#define DD_MISO (1<<DDB4) //pin 12: MISO
#define DD_SCK (1<<DDB5) //pin 13: SCK
#define habilita_SS() clr_bit(PORTB,PB2) // SS habilita em zero 
#define desabilita__SS() set_bit(PORTB,PB2)
#define BOTAO PD2
#define CAL PD3
#define amostras 10 // define numero de amostras para media da leitura
void init_SPI(); // funcao de inicializacao da comunicacao SPI
void ler_AD_spi();
unsigned char escreve_le_SPI(unsigned char dado); // funcao de leitura e escrita de dado via SPI
int cont = 0;
float peso = 0;
float ymax = 100;
float ymin = 0;
float xmax = 3000;
float xmin = 50;
float x, y;

unsigned int peso1 = 0;
unsigned char digitos[4];
void ler_AD_spi();
void imprime_usart(float valor);
void imprime_usart_temperatura(float valor);
void escreve_lcd();
unsigned char tempH,tempL; // variaveis de 8 bits
unsigned int valor16bits; // variavel de 16 bits
unsigned char TEMP[tam_vetor]; // vetor para separacao de caracteres int tempo = 0;
int temp = 0;
int cali = 0;
//-----------------------------------------------------------------------------------------
 int main()
{
    init_SPI();
	USART_Inic(MYUBRR); //inicializa comunicacao usart 
    DDRD = 0B11110011; PORTD = 0B00000000; DDRB = 0XFF;
    while (1) {

        ler_AD_spi();
		peso=valor16bits;
		ident_num(peso,digitos);
		_delay_ms(50); 
		escreve_USART("x = " ); // envia porta serial a media do valor
		imprime_usart(peso);
		x=peso;
		y=(ymax-ymin)/(xmax-xmin);
		y=y*(x-xmin)+ymin;
		 	ident_num(y,digitos);
		
		 y=y*10;
    	 imprime_usart_temperatura(y);
		 
		  escreve_USART("\n " );
		  _delay_ms(50);
    }
} //----------------------------------------------------------------------------------------- //Inicializac?a?o da SPI 
//----------------------------------------------------------------------------------------- 
void escreve_lcd()
{
    peso1 = peso;
	ident_num(peso1,digitos);
    cmd_LCD(digitos[3],1); 
	cmd_LCD(digitos[2],1); 
	cmd_LCD(digitos[1],1); 
	cmd_LCD(digitos[0],1);
	
    _delay_ms(200);
    //inicializa o LCD
}
void ler_AD_spi() {
	  
    _delay_ms(500); // intervalo 
	valor16bits=0; // inicia variavel em zero 0XXXXXXX XXXXX000
    habilita_SS();
	escreve_le_SPI(CH1 | MSB);
    tempH=escreve_le_SPI(0x00); 
	tempL=escreve_le_SPI(0x00);
    desabilita__SS();
    for (int i=0; i<amostras; i++) {
        // inicio de loop de amostras
        // define canal de leitura AD e sequencia dos bits //envia vazio recebe MSB sequencia: 7 bits //envia vazio recebe LSB sequencia: 5 bits
        valor16bits += (tempH<<5) | ( tempL >>3); // Aglutina MSB+LSB descartando os zeros recebidos e soma-se
        _delay_ms(1); // intervalo entre as amostras 
		}
        valor16bits = valor16bits/amostras; // media das amostras
       
    }
    void imprime_usart(float valor) {
        ident_num(valor, TEMP); // rotina separa caracteres 
		USART_Transmite(TEMP[3]); 
		USART_Transmite(TEMP[2]); 
		USART_Transmite(TEMP[1]); 
		USART_Transmite(TEMP[0]);
    }

    void imprime_usart_temperatura(float valor) {
		escreve_USART(" temperatura=" );
        ident_num(valor, TEMP); // rotina separa caracteres 
		USART_Transmite(TEMP[3]); 
		USART_Transmite(TEMP[2]); 
		USART_Transmite(TEMP[1]); 
		escreve_USART("." );
		USART_Transmite(TEMP[0]);
    }
    
    void init_SPI() {
        DDRB = DD_MOSI | DD_SCK | DD_SS; //configurac?a?o dos pinos de entrada e sai?da da SPI
        PORTB |= ((1<<DD_SS)|(1<<DD_MOSI) | (1<<DD_SCK) ); // estado inicial dos pinos
        SPSR &= ~(1<<SPI2X); // status do registrador duplex em zero
        SPCR &= ~((1<<SPIE) | (1<<CPHA) | (1<<DORD)| (1<<CPOL)) ; // bits com zero
        SPCR |= (1<<SPE) | (1<<MSTR) | (1<<SPR1) | (1<<SPR0); // bits com 1: habilita interrupcao dado ajustado na subida e amostragem na descida do sinal de clock
    } //----------------------------------------------------------------------------------------- //Envia e recebe um byte pela SPI
	 //----------------------------------------------------------------------------------------- unsigned char 
unsigned char escreve_le_SPI(unsigned char dado)
    {
        SPDR = dado;
        while(!(SPSR & (1<<SPIF))); return SPDR;
        //envia um byte
        //espera envio
        //retorna o byte recebido
    }
