// Global state
let currentSection = 'intro';
let simulationStates = {
    interrupcoes: { eventCounter: 0, ledState: false, running: false },
    event_loop: { currentStep: 0, buttonState: false, ledState: false, running: false },
    corrotinas: { ledCoroutine: 'idle', adcCoroutine: 'idle', ledState: false, adcValue: 0, running: false },
    timer_scheduling: { systemTicks: 0, running: false, tasks: [] },
    estados: { currentState: 'OFF', nextState: 'RED', running: false }
};

// FSM Data
const fsmData = {
    estados: {
        OFF: { name: 'OFF', color: '#6b7280', led: 'none' },
        RED: { name: 'RED', color: '#ef4444', led: 'red' },
        BLUE: { name: 'BLUE', color: '#3b82f6', led: 'blue' },
        GREEN: { name: 'GREEN', color: '#22c55e', led: 'green' }
    },
    transicoes: {
        OFF: { onoff: 'RED', color: 'OFF' },
        RED: { onoff: 'OFF', color: 'BLUE' },
        BLUE: { onoff: 'OFF', color: 'GREEN' },
        GREEN: { onoff: 'OFF', color: 'RED' }
    }
};

let quizData = [
    {
        question: "Qual técnica oferece menor latência de resposta?",
        options: ["Event Loop", "Interrupções", "Corrotinas", "Timer Scheduling"],
        correct: 1,
        explanation: "Interrupções oferecem a menor latência (2-10 μs) pois respondem imediatamente aos eventos de hardware."
    },
    {
        question: "Qual a principal vantagem do Event Loop?",
        options: ["Baixa latência", "Simplicidade de implementação", "Baixo jitter", "Alta precisão temporal"],
        correct: 1,
        explanation: "Event Loop é simples de implementar e entender, sendo ideal para sistemas que não requerem tempo real crítico."
    },
    {
        question: "O que caracteriza as corrotinas?",
        options: ["Preempção automática", "Suspensão e retomada voluntária", "Uso de hardware timers", "Polling contínuo"],
        correct: 1,
        explanation: "Corrotinas podem suspender e retomar execução voluntariamente, permitindo multitarefa cooperativa."
    },
    {
        question: "Timer Scheduling é ideal para:",
        options: ["Eventos aleatórios", "Tarefas periódicas precisas", "Interfaces simples", "Baixo consumo"],
        correct: 1,
        explanation: "Timer Scheduling é perfeito para tarefas que precisam executar em intervalos precisos e determinísticos."
    },
    {
        question: "Qual técnica tem maior complexidade de implementação?",
        options: ["Event Loop", "Interrupções", "Corrotinas", "Timer Scheduling"],
        correct: 2,
        explanation: "Corrotinas têm maior complexidade pois requerem entendimento de conceitos avançados e disciplina na implementação."
    },
    {
        question: "Em uma máquina de estados, o que define as transições?",
        options: ["Apenas o tempo", "Eventos externos e condições", "Somente interruções", "O compilador"],
        correct: 1,
        explanation: "Transições em máquinas de estados são definidas por eventos externos (como botões) e condições específicas do sistema."
    }
];

let currentQuizQuestion = 0;
let quizScore = 0;
let quizAnswered = false;

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeRecommendationEngine();
    initializeQuiz();
    setupCodeEditors();
    initializeFSM();
    
    // Set initial section
    showSection('intro');
});

// Navigation System
function initializeNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    
    navButtons.forEach(button => {
        button.addEventListener('click', function() {
            const sectionId = this.getAttribute('data-section');
            showSection(sectionId);
            updateActiveNavButton(this);
        });
    });
    
    // Technique card navigation
    const techniqueCards = document.querySelectorAll('.technique-card');
    techniqueCards.forEach(card => {
        card.addEventListener('click', function() {
            const technique = this.getAttribute('data-technique');
            if (technique) {
                showSection(technique);
                updateActiveNavButton(document.querySelector(`[data-section="${technique}"]`));
            }
        });
    });
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        currentSection = sectionId;
    }
}

function updateActiveNavButton(activeButton) {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    activeButton.classList.add('active');
}

// Code Editors Setup
function setupCodeEditors() {
    const editors = document.querySelectorAll('.code-editor');
    editors.forEach(editor => {
        // Basic syntax highlighting effect
        editor.addEventListener('input', function() {
            // Simple visual feedback for editing
            this.style.borderLeft = '4px solid var(--color-primary)';
            setTimeout(() => {
                this.style.borderLeft = '';
            }, 1000);
        });
        
        // Tab key support
        editor.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                e.preventDefault();
                const start = this.selectionStart;
                const end = this.selectionEnd;
                
                this.value = this.value.substring(0, start) + '    ' + this.value.substring(end);
                this.selectionStart = this.selectionEnd = start + 4;
            }
        });
    });
}

// FSM Initialization and Functions
function initializeFSM() {
    updateFSMDisplay();
}

function updateFSMDisplay() {
    const state = simulationStates.estados;
    
    // Update state visuals
    document.querySelectorAll('.fsm-state').forEach(stateElement => {
        stateElement.classList.remove('active');
    });
    
    const currentStateElement = document.getElementById(`state-${state.currentState}`);
    if (currentStateElement) {
        currentStateElement.classList.add('active');
    }
    
    // Update display text
    const currentStateDisplay = document.getElementById('current-state-display');
    const nextStateDisplay = document.getElementById('next-state-display');
    
    if (currentStateDisplay) {
        currentStateDisplay.textContent = state.currentState;
    }
    
    if (nextStateDisplay) {
        nextStateDisplay.textContent = state.nextState;
    }
}

function triggerFSMEvent(eventType) {
    const state = simulationStates.estados;
    const currentState = state.currentState;
    const transitions = fsmData.transicoes[currentState];
    
    if (!transitions) return;
    
    let newState = null;
    let eventDescription = '';
    
    if (eventType === 'onoff') {
        newState = transitions.onoff;
        eventDescription = 'Botão ON/OFF pressionado';
        
        // Update next state based on the transition
        if (newState === 'OFF') {
            state.nextState = 'RED';
        }
    } else if (eventType === 'color') {
        if (currentState !== 'OFF') {
            newState = transitions.color;
            eventDescription = 'Botão Cor pressionado';
        } else {
            addFSMLogEntry('Botão Cor ignorado - LED está desligado');
            return;
        }
    }
    
    if (newState && newState !== currentState) {
        const oldState = currentState;
        state.currentState = newState;
        
        // Log the transition
        addFSMLogEntry(`${eventDescription}: ${oldState} → ${newState}`);
        
        // Update visual
        updateFSMDisplay();
        
        // Add visual transition effect
        animateStateTransition(oldState, newState);
    }
}

function animateStateTransition(fromState, toState) {
    const fromElement = document.getElementById(`state-${fromState}`);
    const toElement = document.getElementById(`state-${toState}`);
    
    // Briefly highlight the transition
    if (fromElement) {
        fromElement.style.transform = 'scale(0.95)';
        setTimeout(() => {
            fromElement.style.transform = '';
        }, 200);
    }
    
    if (toElement) {
        setTimeout(() => {
            toElement.style.transform = 'scale(1.1)';
            setTimeout(() => {
                toElement.style.transform = '';
            }, 300);
        }, 100);
    }
}

function addFSMLogEntry(message) {
    const logElement = document.getElementById('fsm-log-content');
    if (logElement) {
        const timestamp = new Date().toLocaleTimeString().slice(0, 8);
        logElement.innerHTML += `[${timestamp}] ${message}\n`;
        logElement.scrollTop = logElement.scrollHeight;
    }
}

function resetFSM() {
    const state = simulationStates.estados;
    state.currentState = 'OFF';
    state.nextState = 'RED';
    
    updateFSMDisplay();
    
    const logElement = document.getElementById('fsm-log-content');
    if (logElement) {
        logElement.innerHTML = '';
    }
    
    addFSMLogEntry('Sistema reinicializado - Estado: OFF');
}

// Interrupt Simulation
function simulateInterrupt() {
    const state = simulationStates.interrupcoes;
    const pinElement = document.getElementById('int0-pin');
    const ledElement = document.getElementById('led-state');
    const counterElement = document.getElementById('event-counter');
    const logElement = document.getElementById('interrupt-log');
    
    if (!state.running) {
        state.running = true;
        
        // Simulate pin state change
        pinElement.classList.add('active');
        logElement.innerHTML += `[${Date.now() % 10000}ms] INT0 triggered - falling edge detected\n`;
        
        setTimeout(() => {
            pinElement.classList.remove('active');
            
            // Increment counter
            state.eventCounter++;
            counterElement.textContent = state.eventCounter;
            
            // Toggle LED
            state.ledState = !state.ledState;
            ledElement.textContent = `LED: ${state.ledState ? 'ON' : 'OFF'}`;
            ledElement.classList.toggle('on', state.ledState);
            
            logElement.innerHTML += `[${Date.now() % 10000}ms] ISR executed - LED toggled, counter: ${state.eventCounter}\n`;
            logElement.scrollTop = logElement.scrollHeight;
            
            state.running = false;
        }, 100);
    }
}

// Event Loop Simulation  
function simulateEventLoop() {
    const state = simulationStates.event_loop;
    
    if (!state.running) {
        state.running = true;
        runEventLoopCycle();
    }
}

function runEventLoopCycle() {
    const state = simulationStates.event_loop;
    const steps = document.querySelectorAll('.step');
    const buttonStateElement = document.getElementById('button-state');
    const ledStateElement = document.getElementById('eventloop-led-state');
    
    // Reset all steps
    steps.forEach(step => step.classList.remove('active'));
    
    function nextStep() {
        if (state.currentStep >= steps.length) {
            state.currentStep = 0;
        }
        
        steps[state.currentStep].classList.add('active');
        
        switch(state.currentStep) {
            case 0: // Check Buttons
                // Simulate random button press
                if (Math.random() > 0.7) {
                    state.buttonState = true;
                    buttonStateElement.textContent = 'Pressed';
                    buttonStateElement.style.color = 'var(--color-warning)';
                }
                break;
                
            case 1: // Handle Events
                if (state.buttonState) {
                    state.ledState = !state.ledState;
                    ledStateElement.textContent = state.ledState ? 'ON' : 'OFF';
                    ledStateElement.style.color = state.ledState ? 'var(--color-success)' : 'var(--color-text)';
                    state.buttonState = false;
                    buttonStateElement.textContent = 'Released';
                    buttonStateElement.style.color = 'var(--color-text)';
                }
                break;
                
            case 2: // Delay
                // Just visual indication
                break;
        }
        
        state.currentStep++;
        
        if (state.running && state.currentStep < 12) { // Run 4 complete cycles
            setTimeout(nextStep, 800);
        } else {
            state.running = false;
            state.currentStep = 0;
            steps.forEach(step => step.classList.remove('active'));
        }
    }
    
    nextStep();
}

// Coroutines Simulation
function simulateCoroutines() {
    const state = simulationStates.corrotinas;
    
    if (!state.running) {
        state.running = true;
        runCoroutineSimulation();
    }
}

function runCoroutineSimulation() {
    const state = simulationStates.corrotinas;
    const ledStateElement = document.getElementById('led-coroutine-state');
    const adcStateElement = document.getElementById('adc-coroutine-state');
    const ledVisual = document.getElementById('coroutine-led');
    const adcValueElement = document.getElementById('adc-value');
    
    let cycles = 0;
    const maxCycles = 20;
    
    function simulationStep() {
        // LED Blink Coroutine
        if (cycles % 4 === 0) { // Every 4th cycle (simulate 500ms delay)
            state.ledState = !state.ledState;
            ledStateElement.textContent = state.ledState ? 'LED ON' : 'LED OFF';
            ledVisual.classList.toggle('on', state.ledState);
        }
        
        // ADC Read Coroutine
        if (cycles % 2 === 0) { // Every 2nd cycle (simulate 100ms delay)
            adcStateElement.textContent = 'Reading ADC...';
            
            setTimeout(() => {
                state.adcValue = Math.floor(Math.random() * 1024);
                adcValueElement.textContent = state.adcValue;
                adcStateElement.textContent = state.adcValue > 512 ? 'Alert Active' : 'Normal';
                adcStateElement.style.color = state.adcValue > 512 ? 'var(--color-warning)' : 'var(--color-text)';
            }, 200);
        }
        
        cycles++;
        
        if (state.running && cycles < maxCycles) {
            setTimeout(simulationStep, 300);
        } else {
            state.running = false;
            ledStateElement.textContent = 'Idle';
            adcStateElement.textContent = 'Idle';
            adcStateElement.style.color = 'var(--color-text)';
        }
    }
    
    simulationStep();
}

// Timer Scheduling Simulation
function simulateTimerScheduling() {
    const state = simulationStates.timer_scheduling;
    
    if (!state.running) {
        state.running = true;
        state.systemTicks = 0;
        state.tasks = [
            { name: 'LED', period: 1000, lastRun: 0 },
            { name: 'ADC', period: 10, lastRun: 0 }
        ];
        
        runTimerScheduling();
    }
}

function runTimerScheduling() {
    const state = simulationStates.timer_scheduling;
    const ledTimeline = document.getElementById('led-task-timeline');
    const adcTimeline = document.getElementById('adc-task-timeline');
    
    const duration = 5000; // 5 seconds simulation
    const interval = 10; // 10ms intervals
    const totalSteps = duration / interval;
    let currentStep = 0;
    
    function schedulerTick() {
        state.systemTicks += interval;
        const progress = (currentStep / totalSteps) * 100;
        
        // LED Task (1Hz - every 1000ms)
        if (state.systemTicks % 1000 === 0) {
            animateTaskExecution(ledTimeline, progress, 2); // 2% width for execution
        }
        
        // ADC Task (100Hz - every 10ms)  
        if (state.systemTicks % 10 === 0) {
            animateTaskExecution(adcTimeline, progress, 0.5); // 0.5% width for execution
        }
        
        currentStep++;
        
        if (state.running && currentStep < totalSteps) {
            setTimeout(schedulerTick, interval);
        } else {
            state.running = false;
            // Clear timelines
            setTimeout(() => {
                ledTimeline.innerHTML = '';
                adcTimeline.innerHTML = '';
            }, 2000);
        }
    }
    
    schedulerTick();
}

function animateTaskExecution(timeline, position, width) {
    const execution = document.createElement('div');
    execution.className = 'task-execution';
    execution.style.left = `${position}%`;
    execution.style.width = `${width}%`;
    timeline.appendChild(execution);
    
    // Remove after animation
    setTimeout(() => {
        if (execution.parentNode) {
            execution.parentNode.removeChild(execution);
        }
    }, 1000);
}

// Reset Simulations
function resetSimulation(technique) {
    const state = simulationStates[technique];
    state.running = false;
    
    switch(technique) {
        case 'interrupcoes':
            state.eventCounter = 0;
            state.ledState = false;
            document.getElementById('event-counter').textContent = '0';
            document.getElementById('led-state').textContent = 'LED: OFF';
            document.getElementById('led-state').classList.remove('on');
            document.getElementById('interrupt-log').innerHTML = '';
            break;
            
        case 'event_loop':
            state.currentStep = 0;
            state.buttonState = false;
            state.ledState = false;
            document.querySelectorAll('.step').forEach(step => step.classList.remove('active'));
            document.getElementById('button-state').textContent = 'Released';
            document.getElementById('eventloop-led-state').textContent = 'OFF';
            break;
            
        case 'corrotinas':
            state.ledState = false;
            state.adcValue = 0;
            document.getElementById('led-coroutine-state').textContent = 'Idle';
            document.getElementById('adc-coroutine-state').textContent = 'Idle';
            document.getElementById('coroutine-led').classList.remove('on');
            document.getElementById('adc-value').textContent = '0';
            break;
            
        case 'timer_scheduling':
            state.systemTicks = 0;
            document.getElementById('led-task-timeline').innerHTML = '';
            document.getElementById('adc-task-timeline').innerHTML = '';
            break;
            
        case 'estados':
            resetFSM();
            break;
    }
}

// Recommendation Engine
function initializeRecommendationEngine() {
    const scenarioSelect = document.getElementById('scenario-select');
    const resultDiv = document.getElementById('recommendation-result');
    
    scenarioSelect.addEventListener('change', function() {
        const scenario = this.value;
        showRecommendation(scenario, resultDiv);
    });
}

function showRecommendation(scenario, resultDiv) {
    const recommendations = {
        realtime: {
            technique: "Programação Orientada a Interrupções",
            reason: "Para sistemas de tempo real crítico, interrupções oferecem a menor latência (2-10 μs) e resposta determinística.",
            pros: "Resposta imediata, baixo jitter, eficiente uso de CPU",
            example: "Sistemas de controle industrial, aquisição de dados de alta velocidade"
        },
        simple: {
            technique: "Laços de Eventos (Event Loop)",
            reason: "Para interfaces simples, Event Loop oferece simplicidade de implementação e baixo uso de recursos.",
            pros: "Fácil implementação, baixo uso de memória, código intuitivo",
            example: "Interfaces com botões, displays simples, sensores básicos"
        },
        complex: {
            technique: "Multitarefa Cooperativa com Corrotinas",
            reason: "Para sistemas complexos multi-tarefa, corrotinas permitem código sequencial com flexibilidade.",
            pros: "Código legível, flexível, múltiplas tarefas simultâneas",
            example: "Protocolos de comunicação, sequências complexas, state machines"
        },
        periodic: {
            technique: "Escalonamento Baseado em Temporizadores",
            reason: "Para tarefas periódicas precisas, Timer Scheduling garante execução determinística.",
            pros: "Precisão temporal, execução determinística, ideal para controle",
            example: "Controle PID, aquisição periódica, tarefas de manutenção"
        },
        sequential: {
            technique: "Máquinas de Estados com Switch Case",
            reason: "Para controle sequencial com comportamentos bem definidos, FSM oferece estrutura clara e manutenível.",
            pros: "Código estruturado, fácil debugging, comportamento previsível",
            example: "Controle de LEDs, sequências de operação, protocolos simples"
        }
    };
    
    if (scenario && recommendations[scenario]) {
        const rec = recommendations[scenario];
        resultDiv.innerHTML = `
            <div class="recommendation-title">Recomendação: ${rec.technique}</div>
            <div class="recommendation-text">${rec.reason}</div>
            <div class="recommendation-pros"><strong>Vantagens:</strong> ${rec.pros}</div>
            <div><strong>Exemplo de uso:</strong> ${rec.example}</div>
        `;
        resultDiv.classList.add('show');
    } else {
        resultDiv.classList.remove('show');
    }
}

// Quiz System
function initializeQuiz() {
    loadQuizQuestion();
    
    document.getElementById('quiz-next').addEventListener('click', function() {
        nextQuizQuestion();
    });
}

function loadQuizQuestion() {
    if (currentQuizQuestion >= quizData.length) {
        showQuizResults();
        return;
    }
    
    const question = quizData[currentQuizQuestion];
    const questionElement = document.getElementById('quiz-question');
    
    questionElement.innerHTML = `
        <h3>Pergunta ${currentQuizQuestion + 1} de ${quizData.length}</h3>
        <p>${question.question}</p>
        <div class="quiz-options">
            ${question.options.map((option, index) => 
                `<button class="quiz-option" data-answer="${index}" onclick="selectQuizAnswer(${index})">${option}</button>`
            ).join('')}
        </div>
    `;
    
    document.getElementById('quiz-next').style.display = 'none';
    quizAnswered = false;
}

function selectQuizAnswer(selectedIndex) {
    if (quizAnswered) return;
    
    const question = quizData[currentQuizQuestion];
    const options = document.querySelectorAll('.quiz-option');
    
    quizAnswered = true;
    
    options.forEach((option, index) => {
        option.classList.add('disabled');
        
        if (index === question.correct) {
            option.classList.add('correct');
        } else if (index === selectedIndex) {
            option.classList.add('incorrect');
        }
    });
    
    if (selectedIndex === question.correct) {
        quizScore++;
    }
    
    // Show explanation
    const questionElement = document.getElementById('quiz-question');
    questionElement.innerHTML += `
        <div style="margin-top: 16px; padding: 16px; background: var(--color-secondary); border-radius: 8px;">
            <strong>Explicação:</strong> ${question.explanation}
        </div>
    `;
    
    document.getElementById('quiz-next').style.display = 'inline-block';
}

function nextQuizQuestion() {
    currentQuizQuestion++;
    loadQuizQuestion();
}

function showQuizResults() {
    document.getElementById('quiz-question').style.display = 'none';
    document.getElementById('quiz-results').style.display = 'block';
    
    const percentage = Math.round((quizScore / quizData.length) * 100);
    document.getElementById('final-score').textContent = quizScore;
    
    let feedback = '';
    if (percentage >= 80) {
        feedback = 'Excelente! Você domina bem os conceitos de controle de eventos em microcontroladores.';
    } else if (percentage >= 60) {
        feedback = 'Bom trabalho! Você tem uma base sólida, mas pode revisar alguns conceitos.';
    } else {
        feedback = 'Continue estudando! Revise o material e tente novamente para melhorar seu conhecimento.';
    }
    
    document.getElementById('quiz-feedback').textContent = feedback;
}

function restartQuiz() {
    currentQuizQuestion = 0;
    quizScore = 0;
    quizAnswered = false;
    
    document.getElementById('quiz-question').style.display = 'block';
    document.getElementById('quiz-results').style.display = 'none';
    document.getElementById('quiz-next').style.display = 'none';
    
    loadQuizQuestion();
}

// Utility Functions
function addLogEntry(logElement, message) {
    const timestamp = new Date().toLocaleTimeString();
    logElement.innerHTML += `[${timestamp}] ${message}\n`;
    logElement.scrollTop = logElement.scrollHeight;
}

// Export functions for global access
window.simulateInterrupt = simulateInterrupt;
window.simulateEventLoop = simulateEventLoop;
window.simulateCoroutines = simulateCoroutines;
window.simulateTimerScheduling = simulateTimerScheduling;
window.resetSimulation = resetSimulation;
window.selectQuizAnswer = selectQuizAnswer;
window.restartQuiz = restartQuiz;
window.triggerFSMEvent = triggerFSMEvent;
window.resetFSM = resetFSM;