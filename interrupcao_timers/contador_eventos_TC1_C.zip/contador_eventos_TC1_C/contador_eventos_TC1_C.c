//----------------------------------------------------------------------------- //
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.						//	
//----------------------------------------------------------------------------- //
/*   exemplo programa ativando pinos OC0B (PD6) e OC0A (PD5) como saidas PWM e 
e respectivamente executam rotinas TIMER0_COMPA_vect e TIMER0_COMPB_vect a cada compara��o
dos valores de TCNT0 a OCR0A e OCR0B

*/
#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/delay.h>

#define cpl_bit(y,bit) 	(y^=(1<<bit))	//troca o estado l�gico do bit x da vari�vel Y


ISR(TIMER0_COMPA_vect)
{
	cpl_bit(PORTD,4);
	
}

ISR(TIMER0_COMPB_vect)
{
	cpl_bit(PORTD,3);
	
}

int main(void)
{
    DDRD  = 0b01111100;				//pinos OC0B (PD6) e OC0A (PD5) e  como sa�da
	PORTD = 0b10000011;				//zera sa�das e habilita pull-ups nos pinos n�o utilizados	
//	TCCR0A = 0b10100011;			//OC0A e OC0B habilitado  sinais iguais inicio em zero
///		TCCR0A = 0b01010000;			//OC0A e OC0B habilitado  sinais iguais inicio em zero
//	TCCR0B = 0b00000100;			//liga TC0, prescaler = 1 e habilita o pino OC0A para gerar um onda quadrada
//	OCR0A = 150;					//controle do perodo do sinal no pino OC0A
//	OCR0B = 100;						//controle do ciclo ativo do PWM OC0B
//	TCNT0=90;
//	TIMSK0 =  0b00000010;
	
 
    TIMSK0 = _BV(OCIE0A) | _BV(OCIE0B); ;  // Habilita interrupcao TimerCounter0 igualdade TCNT0=0CR0A 0CR0B
	TCCR0A = _BV(WGM01) | _BV(COM0A0) | _BV(COM0B0) ;  // Modo = CTC liga pinos 0C0A e 0C0B com mudan�a de estado na igualdade 
    TCCR0B = _BV(CS02) | _BV(CS00);   // Clock/1024
    OCR0A = 250;          // valor de comparacao. Intervalo= Clock/1024 * 250 ~= 16 ms ISR(TIMER0_COMPA_vect)
     OCR0B = 64;           // valor de comparacao. Intervalo= Clock/1024 * 250 ~= 16 ms ISR(TIMER0_COMPB_vect) deslocamento 16ms *64/250
    sei();  // habilitam as funcoes vetores de interrupcao, nao interfere nos pinos PWM

	
	while(1) 
    {
        //O programa principal vai aqui 
		_delay_ms(10);
	    cpl_bit(PORTD,2);  // exemplo de um programa com atraso
    }
}


//------------------------------------------------------------------------------

/*	OUTROS MODOS

	//MODO CTC
	TCCR0A = 0b01100011;			//OC0A e OC0B habilitado
	TCCR0B = 0b00001001;			//liga TC0, prescaler = 1 e habilita o pino OC0A para gerar um onda quadrada
	OCR0A = 200;					//controle do perodo do sinal no pino OC0A
	OCR0B = 50;						//controle do ciclo ativo do PWM OC0B
	
	
	

	//fast PWM, TOP = 0xFF, OC0A e OC0B habilitados
	TCCR0A = 0b10100011;			//PWM n�o invertido nos pinos OC0A e OC0B
	TCCR0B = 0b00000011;			//liga TC0, prescaler = 64
	OCR0A = 200;					//controle do ciclo ativo do PWM 0C0A
	OCR0B = 50;						//controle do ciclo ativo do PWM OC0B
		
	//fast PWM, TOP = OCR0A com OC0A gerando uma onda quadrada e OC0B um sinal PWM n�o-invertido
	TCCR0A = 0b01100011;			//OC0A e OC0B habilitados
	TCCR0B = 0b00001001;			//liga TC0, prescaler = 1 e ajusta modo para compara��o com OCR0A
	OCR0A = 100;					//controle da periodo do sinal no pino OC0A
	OCR0B = 30;						//controle do ciclo ativo do PWM 0C0B

	//phase correct PWM, TOP = 0xFF
	TCCR0A = 0b10100001;			//OC0A e OC0B habilitados
	TCCR0B = 0b00000001;			//liga TC0, prescaler = 1
	OCR0A = 100;					//controle da periodo do sinal no pino OC0A
	OCR0B = 50;						//controle do ciclo ativo do PWM 0B
	
	//phase correct PWM, TOP = OCR0A
	TCCR0A = 0b01100011;			//OC0A e OC0B habilitado
	TCCR0B = 0b00001001;			//liga TC0, prescaler = 1 e habilita o pino OC0A para gerar um onda quadrada
	OCR0A = 200;					//controle do perodo do sinal no pino OC0A
	OCR0B = 10;						//controle do ciclo ativo do PWM OC0B
	
*/
