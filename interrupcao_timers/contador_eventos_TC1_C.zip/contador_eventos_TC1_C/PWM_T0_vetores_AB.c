//----------------------------------------------------------------------------- //
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.						//	
//----------------------------------------------------------------------------- //
/*   exemplo programa ativando pinos OC0B (PD6) e OC0A (PD5) como saidas PWM e 
e respectivamente executam rotinas TIMER0_COMPA_vect e TIMER0_COMPB_vect a cada compara��o
dos valores de TCNT0 a OCR0A e OCR0B

*/
#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/delay.h>

#define cpl_bit(y,bit) 	(y^=(1<<bit))	//troca o estado l�gico do bit x da vari�vel Y

// vetores de interrupcao
ISR(TIMER0_COMPA_vect)
{
	cpl_bit(PORTD,4);
	
}

ISR(TIMER0_COMPB_vect)
{
	cpl_bit(PORTD,3);
	
}

// rotina principal
int main(void)
{
    DDRD  = 0b01111100;				//pinos OC0B (PD6) e OC0A (PD5) e  como sa�da
	PORTD = 0b10000011;				//zera sa�das e habilita pull-ups nos pinos n�o utilizado	
 
    TIMSK0 = _BV(OCIE0A) | _BV(OCIE0B); ;  // Habilita interrupcao TimerCounter0 igualdade TCNT0=0CR0A 0CR0B
	TCCR0A = _BV(WGM01) | _BV(COM0A0) | _BV(COM0B0) ;  // Modo = CTC liga pinos 0C0A e 0C0B com mudan�a de estado na igualdade 
    TCCR0B = _BV(CS02) | _BV(CS00);   // Clock/1024
    OCR0A = 250;          // valor de comparacao. Intervalo= Clock/1024 * 250 ~= 16 ms ISR(TIMER0_COMPA_vect)
     OCR0B = 64;           // valor de comparacao. Intervalo= Clock/1024 * 250 ~= 16 ms ISR(TIMER0_COMPB_vect) deslocamento 16ms *64/250
    sei();  // habilitam as funcoes vetores de interrupcao, nao interfere nos pinos PWM

	
	while(1) 
    {
        //O programa principal vai aqui 
		_delay_ms(10);
	    cpl_bit(PORTD,2);  // exemplo de um programa com atraso
    }
}
